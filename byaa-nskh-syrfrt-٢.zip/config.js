module.exports = {
  parentId: '', //ايدي الكاتورجي
  probot_ids: ['282859044593598464'], //ايدي برو بوت
  recipientId: '', //ايدي الي حتحولو
  price: 5264 //السعر ب الضريبة
} 